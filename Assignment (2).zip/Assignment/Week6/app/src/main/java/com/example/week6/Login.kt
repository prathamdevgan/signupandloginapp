package com.example.week6

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Login : AppCompatActivity() {
    private lateinit var usernameField: EditText
    private lateinit var passwordField: EditText
    private lateinit var loginButton: Button
    private lateinit var backButton: Button
    private lateinit var errorMessage: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        // Initialize views
        usernameField = findViewById(R.id.username)
        passwordField = findViewById(R.id.password)
        loginButton = findViewById(R.id.login)
        backButton = findViewById(R.id.backButton)
        errorMessage = findViewById(R.id.errorMessage)

        // Enable edge-to-edge support
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Set up login button click listener
        loginButton.setOnClickListener {
            handleLogin()
        }

        // Set up back button click listener
        backButton.setOnClickListener {
            // Handle back button action (e.g., navigate to main screen)
            finish() // This will close the current activity and return to the previous one
        }
    }

    private fun handleLogin() {
        val username = usernameField.text.toString().trim()
        val password = passwordField.text.toString().trim()

        // Check for hardcoded credentials
        if (username == "Android Studio" && password == "Assignment 1") {
            // Redirect to GitHub page
            val intent = Intent(this, MainActivity ::class.java)
            startActivity(intent)
        } else {
            // Show error message
            errorMessage.text = "Username or password is incorrect. Try again!"
            errorMessage.visibility = TextView.VISIBLE
        }
    }
}
