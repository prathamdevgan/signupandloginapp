package com.example.week6

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.week6.databinding.ActivityLogin2Binding

class Login2 : AppCompatActivity() {
    private lateinit var binding: ActivityLogin2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityLogin2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.loginButton.setOnClickListener {
            val email = binding.etUsername.text.toString().trim()
            val password = binding.etPassword.text.toString()

            // Retrieve stored credentials
            val sharedPreferences = getSharedPreferences("UserPref", MODE_PRIVATE)
            val storedEmail = sharedPreferences.getString("USERNAME", null)
            val storedPassword = sharedPreferences.getString("Password", null)

            // Check if credentials match
            if (email == storedEmail && password == storedPassword) {
                // Redirect to GitHub or next activity
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/yourgithubprofile"))
                startActivity(intent)
            } else {
                // Show error message
                Toast.makeText(this, "Username or password is incorrect. Try again!", Toast.LENGTH_SHORT).show()
            }
        }

        binding.backButton.setOnClickListener {
            // Navigate back to the main screen
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
