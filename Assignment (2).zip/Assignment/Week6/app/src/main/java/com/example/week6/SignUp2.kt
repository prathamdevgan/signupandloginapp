package com.example.week6

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.week6.databinding.ActivitySignUp2Binding
import java.util.regex.Pattern

class SignUp2 : AppCompatActivity() {

    private lateinit var binding: ActivitySignUp2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivitySignUp2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        // Validate and create account
        binding.btnCreateAccount.setOnClickListener {
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()
            val confirmPassword = binding.etConfirmPassword.text.toString()

            if (!isValidEmail(email)) {
                showError("Invalid email format")
            } else if (!isValidPassword(password)) {
                showError("Password must be 8-15 characters, include one capital letter, and one special character")
            } else if (password != confirmPassword) {
                showError("Passwords do not match")
            } else {
                saveCredentials(email, password)
                Toast.makeText(this, "Account Created!", Toast.LENGTH_SHORT).show()
            }
        }

        // Back to Main Activity
        binding.btnBackToMain.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // Apply window insets (padding for status bar, etc.)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun showError(message: String) {
        binding.errorMessage.text = message
        binding.errorMessage.visibility = android.view.View.VISIBLE
    }

    private fun isValidEmail(email: String): Boolean {
        val emailPattern = android.util.Patterns.EMAIL_ADDRESS
        return emailPattern.matcher(email).matches()
    }

    private fun isValidPassword(password: String): Boolean {
        val passwordPattern = Pattern.compile("^(?=.*[A-Z])(?=.*[@#\$%^&+=!])(?=\\S+\$).{8,15}\$")
        return passwordPattern.matcher(password).matches()
    }

    private fun saveCredentials(email: String, password: String) {
        val sharedPreferences: SharedPreferences = getSharedPreferences("UserPref", MODE_PRIVATE)
        val editor: SharedPreferences.Editor = sharedPreferences.edit()

        editor.putString("EMAIL", email)
        editor.putString("PASSWORD", password)
        editor.apply()
    }
}
